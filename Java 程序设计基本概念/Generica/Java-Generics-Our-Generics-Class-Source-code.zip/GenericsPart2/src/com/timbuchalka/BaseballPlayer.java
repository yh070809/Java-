package com.timbuchalka;

/**
 * Created by dev on 17/10/2015.
 */
public class BaseballPlayer extends Player {
    public BaseballPlayer(String name) {
        super(name);
    }
}
